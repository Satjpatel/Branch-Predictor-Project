make clean
make
./predict ../traces/186.crafty/crafty.trace.bz2
